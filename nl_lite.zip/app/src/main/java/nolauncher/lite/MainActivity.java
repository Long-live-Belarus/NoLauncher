package nolauncher.lite;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class MainActivity extends Activity {
	
	private LinearLayout linear1;
	private ListView listview1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		listview1 = (ListView) findViewById(R.id.listview1);
	}
	
	private void initializeLogic() {
		Intent startupIntent = new Intent(Intent.ACTION_MAIN); 		startupIntent.addCategory(Intent.CATEGORY_LAUNCHER);  		final android.content.pm.PackageManager pm = getPackageManager(); 		List<android.content.pm.ResolveInfo> activities = pm.queryIntentActivities(startupIntent,1);   		Collections.sort(activities, new Comparator<android.content.pm.ResolveInfo>() {  				public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b) {  					android.content.pm.PackageManager pm = getPackageManager();  					return String.CASE_INSENSITIVE_ORDER.compare(  						a.loadLabel(pm).toString(),  						b.loadLabel(pm).toString());  			}  		});   		ArrayAdapter<android.content.pm.ResolveInfo> adapter = new ArrayAdapter<android.content.pm.ResolveInfo>(  			this, android.R.layout.simple_list_item_1, activities) {  			public View getView(int pos, View convertView, ViewGroup parent) { TextView tv = new TextView(MainActivity.this);  				android.content.pm.ResolveInfo ri = getItem(pos);  			tv.setText(ri.loadLabel(pm));  	LinearLayout lin = new LinearLayout(MainActivity.this);ImageView iv = new ImageView(MainActivity.this);iv.setImageDrawable(ri.loadIcon(pm));lin.addView(iv);lin.addView(tv);tv.setGravity(Gravity.CENTER_VERTICAL);
				tv.setPadding(18,0,0,0);tv.setTextSize(18);
				tv.setTextColor(Color.parseColor("#FFFFFF"));
				tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT ));LinearLayout.LayoutParams p =	new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT);p.width = 100;p.height = 100;p.bottomMargin = 10;p.topMargin = 10;iv.setLayoutParams(p);lin.setPadding(10,10,10,10);return lin;  		}  	};  		listview1.setAdapter(adapter); 		 		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  				@Override 				public void onItemClick(AdapterView adapter, View v, int position, long id) 				{ 					android.content.pm.ResolveInfo resolveInfo = (android.content.pm.ResolveInfo)adapter.getItemAtPosition(position);  					android.content.pm.ActivityInfo activityInfo = resolveInfo.activityInfo;  					if (activityInfo == null) return;  					Intent i = new Intent(Intent.ACTION_MAIN);  					i.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);  					startActivity(i); 			}  			 	});;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		listview1.smoothScrollToPosition((int)(1));
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}